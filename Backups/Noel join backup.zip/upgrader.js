var roleUpgrader = {

    /** @param {Creep} creep **/
    run: function(creep) {

        var sources = creep.room.find(FIND_SOURCES)
        var RoomController = creep.room.controller

        let target = sources[creep.name.split("_")[1] % sources.length]


        if (creep.store.getUsedCapacity() == 0) {
            creep.memory.upgrading = false;
        }

        if (creep.store.getFreeCapacity() == 0) {
            creep.memory.upgrading = true;
        }
        
        if (creep.memory.upgrading == true){
            if (creep.upgradeController(RoomController) == ERR_NOT_IN_RANGE){
                creep.moveTo(RoomController)
            }
        }
        else if (creep.memory.upgrading == false){
            if (creep.harvest(target) == ERR_NOT_IN_RANGE){
                creep.moveTo(target)
            }
        }
    }
}

module.exports = roleUpgrader;